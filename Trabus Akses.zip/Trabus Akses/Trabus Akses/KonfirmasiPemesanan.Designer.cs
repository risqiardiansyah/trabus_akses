﻿namespace Trabus_Akses
{
    partial class KonfirmasiPemesanan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KonfirmasiPemesanan));
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelTentang = new System.Windows.Forms.Label();
            this.labelBeranda = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxNoIden = new System.Windows.Forms.TextBox();
            this.richTextBoxAlamat = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxHp = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxNama = new System.Windows.Forms.TextBox();
            this.buttonBatal = new System.Windows.Forms.Button();
            this.buttonLanjut = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.labelBerangkat = new System.Windows.Forms.Label();
            this.labelHarga = new System.Windows.Forms.Label();
            this.labelJurusan = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.labelJam = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel9.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 63);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(24, 367);
            this.panel2.TabIndex = 17;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.labelTentang);
            this.panel1.Controls.Add(this.labelBeranda);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(870, 63);
            this.panel1.TabIndex = 15;
            // 
            // labelTentang
            // 
            this.labelTentang.AutoSize = true;
            this.labelTentang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTentang.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.labelTentang.Location = new System.Drawing.Point(700, 20);
            this.labelTentang.Name = "labelTentang";
            this.labelTentang.Size = new System.Drawing.Size(129, 17);
            this.labelTentang.TabIndex = 1;
            this.labelTentang.Text = "Tentang Aplikasi";
            // 
            // labelBeranda
            // 
            this.labelBeranda.AutoSize = true;
            this.labelBeranda.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBeranda.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.labelBeranda.Location = new System.Drawing.Point(606, 20);
            this.labelBeranda.Name = "labelBeranda";
            this.labelBeranda.Size = new System.Drawing.Size(69, 17);
            this.labelBeranda.TabIndex = 0;
            this.labelBeranda.Text = "Beranda";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Window;
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.panel8);
            this.panel5.Controls.Add(this.panel9);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.panel3);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(870, 430);
            this.panel5.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(364, 66);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 13);
            this.label13.TabIndex = 6;
            this.label13.Text = "label13";
            this.label13.Visible = false;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel8.Controls.Add(this.pictureBox2);
            this.panel8.Controls.Add(this.label6);
            this.panel8.Location = new System.Drawing.Point(411, 82);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(328, 31);
            this.panel8.TabIndex = 5;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 25);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(31, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "Identitas Pemesan";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.label15);
            this.panel9.Controls.Add(this.label14);
            this.panel9.Controls.Add(this.textBoxNoIden);
            this.panel9.Controls.Add(this.richTextBoxAlamat);
            this.panel9.Controls.Add(this.label10);
            this.panel9.Controls.Add(this.label9);
            this.panel9.Controls.Add(this.textBoxEmail);
            this.panel9.Controls.Add(this.label8);
            this.panel9.Controls.Add(this.textBoxHp);
            this.panel9.Controls.Add(this.label7);
            this.panel9.Controls.Add(this.textBoxNama);
            this.panel9.Controls.Add(this.buttonBatal);
            this.panel9.Controls.Add(this.buttonLanjut);
            this.panel9.Location = new System.Drawing.Point(411, 82);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(325, 332);
            this.panel9.TabIndex = 4;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Font = new System.Drawing.Font("Arial Narrow", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.LightGray;
            this.label15.Location = new System.Drawing.Point(2, 198);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(109, 15);
            this.label15.TabIndex = 21;
            this.label15.Text = "*ktp/kartu pelajar/lainnya";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Font = new System.Drawing.Font("Arial Narrow", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(3, 177);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 17);
            this.label14.TabIndex = 19;
            this.label14.Text = "No. Identitas :";
            // 
            // textBoxNoIden
            // 
            this.textBoxNoIden.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxNoIden.Location = new System.Drawing.Point(103, 175);
            this.textBoxNoIden.Name = "textBoxNoIden";
            this.textBoxNoIden.Size = new System.Drawing.Size(180, 20);
            this.textBoxNoIden.TabIndex = 20;
            this.textBoxNoIden.Tag = "";
            this.textBoxNoIden.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxNoIden_KeyPress);
            // 
            // richTextBoxAlamat
            // 
            this.richTextBoxAlamat.Location = new System.Drawing.Point(103, 222);
            this.richTextBoxAlamat.Name = "richTextBoxAlamat";
            this.richTextBoxAlamat.Size = new System.Drawing.Size(180, 49);
            this.richTextBoxAlamat.TabIndex = 18;
            this.richTextBoxAlamat.Text = "";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(3, 222);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 17);
            this.label10.TabIndex = 17;
            this.label10.Text = "Alamat :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Arial Narrow", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(3, 135);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 17);
            this.label9.TabIndex = 15;
            this.label9.Text = "Email :";
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxEmail.Location = new System.Drawing.Point(103, 133);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(180, 20);
            this.textBoxEmail.TabIndex = 16;
            this.textBoxEmail.Tag = "";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(3, 91);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 17);
            this.label8.TabIndex = 13;
            this.label8.Text = "Nomor HP :";
            // 
            // textBoxHp
            // 
            this.textBoxHp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxHp.Location = new System.Drawing.Point(103, 89);
            this.textBoxHp.Name = "textBoxHp";
            this.textBoxHp.Size = new System.Drawing.Size(180, 20);
            this.textBoxHp.TabIndex = 14;
            this.textBoxHp.Tag = "";
            this.textBoxHp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxHp_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(3, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 17);
            this.label7.TabIndex = 11;
            this.label7.Text = "Nama :";
            // 
            // textBoxNama
            // 
            this.textBoxNama.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxNama.Location = new System.Drawing.Point(103, 47);
            this.textBoxNama.Name = "textBoxNama";
            this.textBoxNama.Size = new System.Drawing.Size(180, 20);
            this.textBoxNama.TabIndex = 12;
            this.textBoxNama.Tag = "";
            // 
            // buttonBatal
            // 
            this.buttonBatal.BackColor = System.Drawing.Color.Silver;
            this.buttonBatal.ForeColor = System.Drawing.Color.Black;
            this.buttonBatal.Location = new System.Drawing.Point(103, 286);
            this.buttonBatal.Name = "buttonBatal";
            this.buttonBatal.Size = new System.Drawing.Size(93, 34);
            this.buttonBatal.TabIndex = 11;
            this.buttonBatal.Text = "Batal";
            this.buttonBatal.UseVisualStyleBackColor = false;
            // 
            // buttonLanjut
            // 
            this.buttonLanjut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonLanjut.ForeColor = System.Drawing.Color.White;
            this.buttonLanjut.Location = new System.Drawing.Point(16, 286);
            this.buttonLanjut.Name = "buttonLanjut";
            this.buttonLanjut.Size = new System.Drawing.Size(93, 34);
            this.buttonLanjut.TabIndex = 10;
            this.buttonLanjut.Text = "Selanjutnya";
            this.buttonLanjut.UseVisualStyleBackColor = false;
            this.buttonLanjut.Click += new System.EventHandler(this.buttonLanjut_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel7.Controls.Add(this.pictureBox1);
            this.panel7.Controls.Add(this.label1);
            this.panel7.Location = new System.Drawing.Point(56, 82);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(328, 31);
            this.panel7.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(30, 25);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(31, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Keterangan Tiket";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.labelJam);
            this.panel6.Controls.Add(this.label12);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.labelBerangkat);
            this.panel6.Controls.Add(this.labelHarga);
            this.panel6.Controls.Add(this.labelJurusan);
            this.panel6.Location = new System.Drawing.Point(56, 82);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(328, 332);
            this.panel6.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Font = new System.Drawing.Font("Arial Narrow", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(13, 204);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(180, 17);
            this.label12.TabIndex = 10;
            this.label12.Text = "Batal Untuk Membatalkan Pesanan";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("Arial Narrow", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(6, 187);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(266, 17);
            this.label11.TabIndex = 9;
            this.label11.Text = "* Klik Selanjutnya untuk melanjutkan pemesanan atau";
            // 
            // labelBerangkat
            // 
            this.labelBerangkat.AutoSize = true;
            this.labelBerangkat.BackColor = System.Drawing.Color.White;
            this.labelBerangkat.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBerangkat.ForeColor = System.Drawing.Color.Black;
            this.labelBerangkat.Location = new System.Drawing.Point(13, 105);
            this.labelBerangkat.Name = "labelBerangkat";
            this.labelBerangkat.Size = new System.Drawing.Size(264, 20);
            this.labelBerangkat.TabIndex = 4;
            this.labelBerangkat.Text = "- Berangkat Pada: Jum\'at, 25 Agustus 2019";
            // 
            // labelHarga
            // 
            this.labelHarga.AutoSize = true;
            this.labelHarga.BackColor = System.Drawing.Color.White;
            this.labelHarga.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHarga.ForeColor = System.Drawing.Color.Black;
            this.labelHarga.Location = new System.Drawing.Point(13, 75);
            this.labelHarga.Name = "labelHarga";
            this.labelHarga.Size = new System.Drawing.Size(160, 20);
            this.labelHarga.TabIndex = 3;
            this.labelHarga.Text = "- Harga Tiket: Rp. 75.000 ";
            this.labelHarga.Click += new System.EventHandler(this.label3_Click);
            // 
            // labelJurusan
            // 
            this.labelJurusan.AutoSize = true;
            this.labelJurusan.BackColor = System.Drawing.Color.White;
            this.labelJurusan.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelJurusan.ForeColor = System.Drawing.Color.Black;
            this.labelJurusan.Location = new System.Drawing.Point(13, 47);
            this.labelJurusan.Name = "labelJurusan";
            this.labelJurusan.Size = new System.Drawing.Size(172, 20);
            this.labelJurusan.TabIndex = 2;
            this.labelJurusan.Text = "- Jurusan Bandung - Depok";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(850, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(20, 430);
            this.panel3.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel4.Controls.Add(this.dataGridView1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 430);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(870, 60);
            this.panel4.TabIndex = 16;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Enabled = false;
            this.dataGridView1.Location = new System.Drawing.Point(29, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(93, 54);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.Visible = false;
            // 
            // labelJam
            // 
            this.labelJam.AutoSize = true;
            this.labelJam.BackColor = System.Drawing.Color.White;
            this.labelJam.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelJam.ForeColor = System.Drawing.Color.Black;
            this.labelJam.Location = new System.Drawing.Point(13, 133);
            this.labelJam.Name = "labelJam";
            this.labelJam.Size = new System.Drawing.Size(168, 20);
            this.labelJam.TabIndex = 11;
            this.labelJam.Text = "Jam Keberangkatan: 17:00";
            // 
            // KonfirmasiPemesanan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(870, 490);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "KonfirmasiPemesanan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "KonfirmasiPemesanan";
            this.Load += new System.EventHandler(this.KonfirmasiPemesanan_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelTentang;
        private System.Windows.Forms.Label labelBeranda;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.RichTextBox richTextBoxAlamat;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxHp;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxNama;
        private System.Windows.Forms.Button buttonBatal;
        private System.Windows.Forms.Button buttonLanjut;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label labelBerangkat;
        private System.Windows.Forms.Label labelHarga;
        private System.Windows.Forms.Label labelJurusan;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxNoIden;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label labelJam;
    }
}